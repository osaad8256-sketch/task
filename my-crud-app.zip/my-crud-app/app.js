const express = require('express');
const mongoose = require('mongoose');
const path = require('path');

const app = express();
app.use(express.json());

// ✅ خدمة الملفات الثابتة (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));

// ========== الاتصال بقاعدة البيانات MongoDB Atlas ==========
mongoose.connect('mongodb+srv://202403221_db_user:UA55oAwR5XcH4WSQ@cluster0.fcb9scj.mongodb.net/testDB?appName=Cluster0')
  .then(() => console.log('✅ Connected to MongoDB'))
  .catch(err => console.log('❌ MongoDB Error:', err));

const User = require('./models/User');

// ============== 1- POST: إضافة 5 مستخدمين ==============
app.post('/users', async (req, res) => {
  try {
    const usersData = [
      { name: 'Ahmed', age: 25, city: 'Cairo' },
      { name: 'Sara', age: 22, city: 'Alex' },
      { name: 'Mohamed', age: 30, city: 'Giza' },
      { name: 'Fatma', age: 27, city: 'Mansoura' },
      { name: 'Omar', age: 24, city: 'Tanta' },
    ];
    
    const users = await User.insertMany(usersData);
    res.status(201).json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============== 2- GET: جلب جميع المستخدمين ==============
app.get('/users', async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============== 3- GET by ID: جلب مستخدم باستخدام _id ==============
app.get('/users/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============== 4- PATCH: تحديث مستخدم باستخدام _id ==============
app.patch('/users/:id', async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============== 5- DELETE: حذف مستخدم باستخدام _id ==============
app.delete('/users/:id', async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============== TEST endpoint ==============
app.get('/test', (req, res) => {
  res.send('Server is working ✅');
});

// ============== تشغيل السيرفر ==============
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});